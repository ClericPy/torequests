import logging


dummy_logger = logging.getLogger('torequests.dummy')
main_logger = logging.getLogger('torequests.main')