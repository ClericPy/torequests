import time
from torequests.dummy import Requests

# TODO