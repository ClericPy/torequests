#! coding: utf-8

import sys

PY2 = (sys.version_info[0] == 2)
PY3 = (sys.version_info[0] == 3)
PY35_PLUS = sys.version_info[0] >= 3 and sys.version_info[1] >= 5
